// ===UserScript===
// @name         ResEdit - Supplementary Scripts
// @version      1.0
// @author       Jay Snyder
// @description  Scripts to supplement features missing from hardcoded ResEdit changes.
// @match        https://www.vacasa.com/admin/resedit.php*
// @include      https://www.vacasa.com/admin/dashboard/reservation/finance*
// @include      https://www.vacasa.com/admin/dashboard/finance/ownerCredit/edit*
// @include      https://www.vacasa.com/admin/dashboard/tickets/editMaintenance*
// @include      https://www.vacasait.com/admin/resedit.php*
// @include      https://www.vacasait.com/admin/dashboard/reservation/finance*
// @include      https://www.vacasait.com/admin/dashboard/finance/ownerCredit/edit*
// @include      https://www.vacasait.com/admin/dashboard/tickets/editMaintenance*
// @run-at       document-end
// @icon         https://www.vacasa.com/favicon.ico
// @require      https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js
// @grant        GM_addStyle
// @grant        GM_setClipboard
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_notification
// ===/UserScript===


// https://www.vacasa.com/admin/dashboard/libs/bootstrap/js/bootstrap.min.js

// must always match the version above
var versionNum = "1.0";

var docUrl = window.location.href;

// locally stored settings bools
var settings = {
  BANNERS_INTL: false,
  BANNERS_THIRD: false,
  COPY_TOTALS: false,
  EMAIL_SCROLL: false,
  MAX_REFUND: false,
  MAX_TRANSFER: false,
  ORGANIZED_INFO: false,
  PORTAL_NEW_WIN: false,
  REFUND_HASH: true,
  THIRD_BUTTON: false,
  THIRD_GMAIL_NUM: 0,
  TICKET_TEMPLATE: false
};

(function () {

  "use strict";

  var RES = {

    // RES STYLE RULES/LINKS

    css: {
      rules: `@font-face{font-family:wigrum-medium;src:url(https://vacasa.frontify.com/upload/screens/3/8b22cb58c684785078ac5bb0b12eb387.eot?#iefix);src:url(https://vacasa.frontify.com/upload/screens/3/8b22cb58c684785078ac5bb0b12eb387.eot?#iefix) format("eot"),url(https://vacasa.frontify.com/upload/screens/3/b75b79e22ebc54fc5c8e6bce7250dab0.woff) format("woff");font-weight:400;font-style:normal}
        #RES-cc-modal>.modal-dialog{width:640px}
        #RES-ocrc-modal>.modal-dialog{width:400px}
        .body-default{padding:80px 16px 16px 16px!important;}
        .caret{-webkit-transition:transform .2s ease-in 0s;transition:transform .2s ease-in 0s}
        .caret.rotate{transform:rotate(-90deg)}
        .collapse-divider{display:none}
        .copy-area{-webkit-transition:all .4s ease-in .15s;background-color:rgba(240,243,245,1);border-radius:4px;border:1px solid transparent;cursor:pointer;display:inline-block;padding:2px 2px;transition:all .4s ease-in .15s}
        .copy-area:hover{-webkit-transition:all .2s ease-in 0s;background-color:rgba(209,218,224,1);box-shadow:0 1px 2px rgba(0,0,0,.3);transform:translate(-1px,-1px);transition:all .2s ease-in 0s}
        .copy-area.info{background-color:rgba(205,223,228,1)}
        .copy-area.info:hover{background-color:rgba(189,213,219,1)}
        .copy-area:before{-webkit-transition:all .2s ease-out 0s;background-color:rgba(245,247,248,.85);border-radius:2px;box-shadow:0 1px 2px rgba(0,0,0,.3);color:#4ca0c4;content:'\\f0c5';display:flex;font-family:'Font Awesome 5 Free';font-size:12px;font-weight:900;opacity:0;padding:2px;position:absolute;right:0;top:0;transform:translate(0,0) scale(0,0);transition:all .2s ease-out 0s}
        .copy-area:hover:before{-webkit-transition:all .2s ease-out .5s;opacity:1;transform:translate(12px,-12px) scale(1,1);transition:all .2s ease-out .5s}
        .copy-btn{-webkit-transition:all .2s ease;background-color:#ebebeb;border-radius:0 6px 6px 0;color:#00a6bb;padding:2px;transition:all .2s ease}
        .copy-btn:hover{background-color:#e1e1e1;color:#00626e;cursor:pointer}
        .copy-btn-body{-webkit-transition:all .2s ease-in .15s;background-color:#f0f3f5;border-radius:2px;box-shadow:0 1px 2px rgba(0,0,0,.05);display:inline-block;padding:4px;transition:all .2s ease-in .15s}
        .copy-btn-body:hover{-webkit-transition:all .2s ease-in 0s;background-color:#ffd00a;box-shadow:0 1px 2px rgba(0,0,0,.3);color:#2c3439;transform:translate(-1px,-1px);transition:all .2s ease-in 0s}
        .copy-btn-panel{-webkit-transition:all .2s ease-in .15s;background-color:transparent;border-radius:2px;box-shadow:0 1px 2px rgba(0,0,0,0);display:inline-block;padding:4px;transition:all .2s ease-in .15s}
        .copy-btn-panel:hover{-webkit-transition:all .2s ease-in 0s;background-color:#ffd00a;box-shadow:0 1px 2px rgba(0,0,0,.3);color:#2c3439;transform:translate(-1px,-1px);transition:all .2s ease-in 0s}
        .copy-body{background-color:#f7f7f7;padding:2px 4px}
        .copy-body.top{border-top-left-radius:6px}
        .copy-body.bottom{border-bottom-left-radius:6px}
        .disabled,.disabled>a{color:#ccc!important;cursor:default!important;pointer-events:none!important;text-shadow:none!important}
        .dropdown-menu.res>.divider{background-color:transparent!important;padding-top:0!important;width:100%}
        .dropdown.res>.dropdown-menu{margin-top:16px!important}
        .dropdown-menu.res>li>a{padding-right:38px!important}
        .dropdown-menu.res>li>.fas{margin-right:8px;margin-top:-20px}
        .dropdown-submenu{position:relative}
        .dropdown-submenu>.dropdown-menu{display:none;margin-right:-16px;right:100%!important;top:-5px}
        .submenu-right>.dropdown-menu{left:100%!important;margin-left:-16px;top:-5px}
        .dropdown-submenu:hover>.dropdown-menu{display:block}
        .fas{text-decoration:none!important}
        .form-control.no-resize{resize:none}
        .form-group.invisible{opacity:0;visibility:hidden}
        .form-group.no-margin-bottom{margin-bottom:0}
        .full-width{width:100%}
        .glyphicon-ok-sign.text-success{color:#6ba342!important}
        .glyphicon-remove-sign{color:#707579!important}
        .helper>dd{color:#000;margin:8px}
        .h-stretch{padding-right:8px!important;text-align:justify!important;width:100%!important}
        .info-area{-webkit-transition:all .2s ease-in 0s;color:#4d7180;cursor:pointer;transition:all .2s ease-in 0s}
        .info-area:hover{color:#003349!important;text-decoration:none!important}
        .info-stasis>.fas,.info-stasis>a{color:#4d7180!important}
        .inquiry-note{background-color:#e5ebed;color:#1a475b;display:block;margin:16px 8px}
        .md-heading{color:#2c3439!important;font-family:wigrum-medium,sans-serif!important;font-size:21px!important;letter-spacing:-.2px!important;line-height:28px!important}
        .modal-open{overflow-y:auto!important;}
        .modal-status{padding:6px 0;margin-bottom: 0px;font-weight:400}
        .nav.nav-pills.pills-warning{border-radius:2px;padding:0 4px}
        .nav.nav-pills.pills-warning>li{border-radius:2px;font-size:12px}
        .nav.nav-pills.pills-warning>li>a,.nav.nav-pills.pills-warning>li>a:focus{-webkit-transition:all .2s ease-in .15s;background-color:transparent;display:inline-block;margin-right:4px;padding:4px 8px;transition:all .2s ease-in .15s}
        .nav.nav-pills.pills-warning>li>a.active,.nav.nav-pills.pills-warning>li>a:hover{-webkit-transition:all .2s ease-in 0s;background-color:rgba(255,208,10,.55);box-shadow:0 1px 2px rgba(0,0,0,.3);color:#2c3439;transform:translate(-1px,-1px);transition:all .2s ease-in 0s}
        .navbar-brand{padding:10px 15px!important}
        .navbar-collapse{margin-right:0!important}
        .navbar-collapse.in{overflow-y:visible!important}
        .navbar-header>.navbar-text{line-height:1.14!important;margin-bottom:10px!important;margin-top:10px!important;white-space:nowrap!important}
        .nav-details.nav-pills,.nav-details.nav-tabs{background-color:#f0f3f5;border-radius:2px;padding:4px}
        .nav-details.nav-tabs{border-radius:2px 2px 0 0!important;padding:4px 4px 0 4px!important}
        .nav-details.nav-pills>li:not(.active)>a:hover,.nav-details.nav-tabs>li:not(.active)>a:hover{background-color:rgba(255,208,10,.35);border-color:transparent;color:#707579}
        .nav-details.nav-pills>li.active>a,.nav-details.nav-pills>li.active>a:focus,.nav-details.nav-pills>li.active>a:hover{background-color:#fff;border:1px solid #ddd;box-shadow:0 1px 2px rgba(0,0,0,.05);color:#000}
        .nav-details.nav-pills>li>a,.nav-details.nav-tabs>li>a{-webkit-transition:all .4s ease;border-radius:2px;margin:2px;transition:all .4s ease}
        .nav-details.nav-tabs>li>a{border-radius:2px 2px 0 0!important;margin:2px 2px 0 2px!important}
        .nav-details.nav-pills>li>a{border:1px solid transparent}
        .no-wrap{white-space:nowrap!important}
        .no-bottom-margin{margin-bottom:0!important;}
        p{margin-bottom:8px!important}
        .panel-divider{background-color:#ddd;height:1px;margin:24px 0;width:100%}
        .panel-table{border-collapse:separate;border-spacing:0 4px;color:inherit}
        .panel-table>tbody>tr>td{border-bottom:1px solid #ebebeb;padding:2px 0}
        .panel-table>tbody>tr:last-child>td{border-bottom:none!important}
        .panel-table>tbody>tr>td:nth-of-type(1){min-width:160px!important;width:160px!important}
        .alert>.panel-table,.alert>div>.panel-table{font-size:inherit!important}
        .alert>.panel-table>tbody>tr>td,.alert>div>.panel-table>tbody>tr>td{border-bottom:none!important;padding:0 0}
        .alert>.panel-table>tbody>tr>td:nth-of-type(1),.alert>div>.panel-table>tbody>tr>td:nth-of-type(1){vertical-align:top!important}
        .panel-unpad{padding-top:0!important}
        .pointer-default{cursor:default!important}
        .popover.left{margin-left:8px!important}
        .popover{font-size:14px!important;min-width:275px!important}
        .popover>*,.popover>*>*{font-family:inherit;font-size:inherit;font-weight:400}
        .popover-code{font-size:12px;line-height:1.428}
        .popover-content{max-height:400px;overflow-y:auto}
        .popover-content>.table-condensed{border-collapse:separate!important;border-spacing:0 2px}
        .popover-content>.table-condensed>tbody>tr>td{font-size:14px!important;padding:2px 4px!important}
        .popover-h4{line-height:1.428!important;margin:0 0 2px 0!important}
        .popover-secondary-title{margin:10px -14px 10px!important}
        .pulsate{-webkit-animation:pulsate 1s ease-in-out infinite;animation:pulsate 1s ease-in-out infinite;opacity:1}
        @-webkit-keyframes pulsate{
        0%{opacity:1}
        50%{opacity:.3}
        100%{opacity:1}
        }
        @keyframes pulsate{
        0%{opacity:1}
        50%{opacity:.3}
        100%{opacity:1}
        }
        .results{font-size: 12px; border-collapse: collapse;}
        .results > * > tr > td, .results > * > tr > th {padding: 5px; border: 1px solid #ddd;}
        .row-eq-height{display:flex;display:-ms-flexbox;display:-webkit-box;display:-webkit-flex}
        .settings-finance{padding:16px 9px}
        .tny-heading-caps{font-family:wigrum-medium,sans-serif!important;font-size:12px!important;letter-spacing:-.38px!important;line-height:16px!important;text-transform:uppercase!important}
        .tab-pane{background-color:inherit;}
        .table-condensed.no-spacing{border-spacing:0!important}
        .table-divider{background-color:#ebebeb;height:1px;margin:8px 0!important;width:100%}
        .table-inline{display:table}
        .table-inline>.cell{display:table-cell}
        .text-alertness{color:#d62e4f}
        .text-awareness{color:#c29024}
        .text-secondary{color:#4ca0c4}
        .text-right.extra-padding{padding-right:8px!important}
        .tooltip{width:200px!important}
        .tooltip.in{opacity:1!important}
        .tooltip-inner{background-image:linear-gradient(to bottom,#fee5ad 0,#fedd93 100%);background-repeat:repeat-x;border:1px solid #ddaa02!important;color:#ab5901!important;font-size:13px}
        .tooltip.right>.tooltip-arrow{border-right-color:#e3af02!important}
        .tooltip.bottom>.tooltip-arrow{border-bottom-color:#e3af02!important}
        .tooltip.left>.tooltip-arrow{border-left-color:#e3af02!important}
        .tooltip.top>.tooltip-arrow{border-top-color:#e3af02!important}
        .tooltip-inner.danger{background-image:linear-gradient(to bottom,#f1c6c6 0,#e9a8a8 100%);border:1px solid #e18989!important;color:#d24c4c!important}
        .tooltip.right>.tooltip-arrow.danger{border-right-color:#e18989!important}
        .tooltip.bottom>.tooltip-arrow.danger{border-bottom-color:#e18989!important}
        .tooltip.left>.tooltip-arrow.danger{border-left-color:#e18989!important}
        .tooltip.top>.tooltip-arrow.danger{border-top-color:#e18989!important}
        .trip-portal-link{-webkit-box-shadow:0 1px 2px rgba(0,0,0,.05);-webkit-transition:all .4s ease;background-color:#fff;border-radius:2px;border:1px solid #d7d7d7;box-shadow:0 1px 2px rgba(0,0,0,.05);color:rgba(0,166,187,1);font-size:16px!important;font-weight:500!important;height:40px!important;line-height:34px!important;min-width:180px!important;padding:2px 5px!important;position:relative;transition:all .4s ease}
        .trip-portal-link:hover{border:1px solid rgba(0,0,0,.4);color:rgba(0,166,187,1)!important}
        #combinedID,#grandTotal,#grandTotalFees,#grandTotalRent,#grandTotalTax,.unitFees,.unitRent,.unitTax,.unitTotal{float:right!important;font-family:Menlo,Monaco,Consolas,"Courier New",monospace!important}
        .version{opacity:.45}
        .visual-tabs-disabled{background-image:url("https://i.imgur.com/aPvj4BR.png");background-position:center 80%;background-repeat:no-repeat;}`,

      sheets: `<link rel="stylesheet" href="https://www.vacasa.com/admin/dashboard/libs/css/template_internal.css?v=1.5">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/solid.css" integrity="sha384-rdyFrfAIC05c5ph7BKz3l5NG5yEottvO/DQ0dCrwD8gzeQDjYBHNr1ucUpQuljos" crossorigin="anonymous">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/fontawesome.css" integrity="sha384-u5J7JghGz0qUrmEsWzBQkfvc8nK3fUT7DCaQzNQ+q4oEXhGSx+P2OqjWsfIRB8QT" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,700" rel="stylesheet">`
    },


    // SETTINGS ///////////////////////////////////////////////////////////////

    settings: {

      init: function () {

        let settingsHtml = "";

        function tickSettings(constant) {
          if (constant === true) {
            return "checked";
          }
        }

        // iterate through and load settings
        $.each(settings, function (key, value) {
          settings[key] = GM_getValue(key, value);
        });

        // the html for our settings popover
        settingsHtml =
          `<p>
            <div class="checkbox settings"><label data-toggle="tooltip" data-container="#RES-btn-pop-settings" data-trigger="focus hover" data-placement="left" title="When you click the View Guest Portal button, it will open in a new tab instead"><input id="RES-check-settings-PORTAL_NEW_WIN" data-settings="PORTAL_NEW_WIN" type="checkbox" ${tickSettings(settings.PORTAL_NEW_WIN)}> Portal in New Window</label></div>
            <div class="checkbox settings"><label data-toggle="tooltip" data-container="#RES-btn-pop-settings" data-trigger="focus hover" data-placement="left" title="The Email Log section will start to scroll after it reaches a certain height, instead of filling the whole page"><input id="RES-check-settings-EMAIL_SCROLL" data-settings="EMAIL_SCROLL" type="checkbox" ${tickSettings(settings.EMAIL_SCROLL)}> Scrolling Email Log</label></div>
            <div class="checkbox settings"><label data-toggle="tooltip" data-container="#RES-btn-pop-settings" data-trigger="focus hover" data-placement="left" title="Creates &quot;Max&quot; buttons next to refundable transactions, to quickly fill in the maximum available amount"><input id="RES-check-settings-MAX_REFUND" data-settings="MAX_REFUND" type="checkbox" ${tickSettings(settings.MAX_REFUND)}> Max Refund Button</label></div>
          </p>
          <h3 class="popover-title popover-secondary-title">Banners</h3>
          <p>
            <div class="checkbox settings"><label data-toggle="tooltip" data-container="#RES-btn-pop-settings" data-trigger="focus hover" data-placement="left" title="Adds informative links to the banners of international reservations, for quick reference"><input id="RES-check-settings-BANNERS_INTL" data-settings="BANNERS_INTL" type="checkbox" ${tickSettings(settings.BANNERS_INTL)}> International Ops</label></div>
            <div class="checkbox settings"><label data-toggle="tooltip" data-container="#RES-btn-pop-settings" data-trigger="focus hover" data-placement="left" title="Adds collapsible 3rd Party Helper sections to the banners of 3rd party reservations, for quick reference"><input id="RES-check-settings-BANNERS_THIRD" data-settings="BANNERS_THIRD" type="checkbox" ${tickSettings(settings.BANNERS_THIRD)}> 3rd Party Helper</label></div>
          </p>
          <h3 class="popover-title popover-secondary-title">Buttons</h3>
          <p>
            <div class="checkbox settings"><label data-toggle="tooltip" data-container="#RES-btn-pop-settings" data-trigger="focus hover" data-placement="left" title="If you're on the 3rd Party Team, this will enable a navbar button with additional features"><input id="RES-check-settings-THIRD_BUTTON" data-settings="THIRD_BUTTON" type="checkbox" ${tickSettings(settings.THIRD_BUTTON)}> 3rd Party</label></div>
          </p>
          <h3 class="popover-title popover-secondary-title">Finances</h3>
          <p>
            <div class="checkbox settings"><label data-toggle="tooltip" data-container="#RES-btn-pop-settings" data-trigger="focus hover" data-placement="left" title="Reorganizes the finance information and totals for better readability and quicker workflow"><input id="RES-check-settings-ORGANIZED_INFO" data-settings="ORGANIZED_INFO" type="checkbox" ${tickSettings(settings.ORGANIZED_INFO)}> Organized Info</label></div>
            <div class="checkbox settings"><label data-toggle="tooltip" data-container="#RES-btn-pop-settings" data-trigger="focus hover" data-placement="left" title="Creates &quot;Max&quot; buttons for credit transfers, to quickly fill in the maximum available amount"><input id="RES-check-settings-MAX_TRANSFER" data-settings="MAX_TRANSFER" type="checkbox" ${tickSettings(settings.MAX_TRANSFER)}> Max Transfer Button</label></div>
          </p>
          <h3 class="popover-title popover-secondary-title">Tickets</h3>
          <p>
            <div class="checkbox settings"><label data-toggle="tooltip" data-container="#RES-btn-pop-settings" data-trigger="focus hover" data-placement="left" title="When creating a New Ticket, the standard ticket template will automatically be filled in."><input id="RES-check-settings-TICKET_TEMPLATE" data-settings="TICKET_TEMPLATE" type="checkbox" ${tickSettings(settings.TICKET_TEMPLATE)}> Ticket Template</label></div>
          </p>
          <h3 class="popover-title popover-secondary-title">Notes</h3>
          <p>
            <div class="text-info"><p><small><em>Page must be refreshed for changes to take place.</em></small></p></div>
          </p>`;

        // fire up the html above
        $("#RES-btn-pop-settings").attr("data-original-title", `Settings <span class="version"><small>v${versionNum} SUPPLEMENTARY</small></span>`).attr("data-content", settingsHtml);
      },

      toggle: function (element) {

        GM_setValue(element.attr("data-settings"), element.prop("checked"));

        RES.settings.init();

        if (element.attr("data-settings") === "THIRD_BUTTON") {
          let agentGmailNum = 0;

          // if the checkbox is being ticked...
          if ($("#RES-check-settings-THIRD_BUTTON").is(":checked")) {
            // prompt the guest for their Vacacas Gmail inbox number
            agentGmailNum = prompt(`What's the number that appears in your Vacasa Gmail URL?\n\nExample: mail.google.com/mail/u/0/\nNumber: 0`, settings.THIRD_GMAIL_NUM);

            // if the agent didn't cancel the prompt, set and save the number they provided
            if (agentGmailNum !== null) {
              GM_setValue("THIRD_GMAIL_NUM", agentGmailNum);
              GM_setValue("THIRD_BUTTON", true);

            } else {
              // if the agent cancelled the prompt, set nothing and don't tick the box
              $("#RES-check-settings-THIRD_BUTTON").removeAttr("checked");
              GM_setValue("THIRD_BUTTON", false);
            }
          } else {
            // the box is being unticked, save the value accordingly
            GM_setValue("THIRD_BUTTON", false);
          }

          // reload settings to reflect changes
          RES.settings.init();
        }
      }
    },


    // RES INIT ///////////////////////////////////////////////////////////////

    init: function () {

      // include the stylesheet used on the admin dashboard, and the FontAwesome CDN
      $("head").append(RES.css.sheets);

      // add a handfull of style rules we need to make things look pretty
      GM_addStyle(RES.css.rules);

      // // enable Bootstrap popovers and tooltips, with html capabilities
      // $(function () {
      //   $("[data-toggle='popover']").popover({
      //     html: true
      //   });

      //   $("[data-toggle='tooltip']").tooltip({
      //     delay: {
      //       "show": 2500,
      //       "hide": 100
      //     },
      //     html: true
      //   });
      // });

      // add settings button to any res finance page
      if (docUrl.indexOf("/admin/dashboard/reservation/finance/") > -1) {
        // $("#navbar-main > div:nth-of-type(1) > ul:nth-of-type(1)").prepend(
        //   `<li class="dropdown">
        //     <button id="RES-btn-pop-settings" class="btn-link settings-finance" role="button" data-toggle="popover" data-container="#navbar-main" data-trigger="click" data-placement="bottom" data-title="null">
        //       <span title="ResEdit Suite Settings"><i class="fas fa-cog"></i></span>
        //     </button>
        //   </li>`
        // );

        RES.settings.init();
      }

      // create listener for when settings checkboxes are toggled, that saves the settings and reloads/updates the popover
      $(document).on("click", "div.settings > label > input", function (e) {
        RES.settings.toggle($(this));
      });

      // // because popovers are dynamically generated, this snippet of code helps
      // // our settings popover elements function the way they should
      // $(document).on("click", "#RES-btn-pop-settings", function (e) {
      //   // enable Bootstrap tooltips, with html capabilities
      //   $(function () {
      //     $("[data-toggle='tooltip']").tooltip({
      //       delay: {
      //         "show": 500,
      //         "hide": 100
      //       },
      //       html: true
      //     });
      //   });

      //   $("div.popover-content").scroll(function () {
      //     $("[data-toggle='tooltip']").tooltip("hide");
      //   });
      // });
    },


    // INTRA-DOMAIN MODULES ///////////////////////////////////////////////////

    modules: {

      // RESEDIT
      // /admin/resedit.php

      resedit: function () {

        var unit = {
          code: "",
          id: 0,
          lomId: 0,
          name: "",
          tagline: ""
        };

        var reservation = {
          author: "",
          cancel: {
            raw: "",
            date: ""
          },
          created: {
            raw: "",
            timestamp: "",
            date: "",
            time: ""
          },
          createdDate: "",
          external: "",
          gridLink: "",
          id: 0,
          nights: {
            first: "",
            last: "",
            checkOut: ""
          },
          source: {
            raw: "",
            num: 0,
            name: ""
          },
          type: 0,

          searchHiverAirbnb: function () {
            let unitTaglineShort = "";

            if (unit.tagline === "") {
              // indicate that the link is now loading
              RES.indicateLoading("#RES-li-THIRD_BUTTON-airbnb-hiver", true, "", "", true);

              // load Listing page in the background, then parse out information we need from it to compile search terms
              $.get(`/admin/dashboard/units/listing?UnitID=${unit.id}`, function (data) {
                unit.tagline = $(data).find("#UnitTitle").val();
                unitTaglineShort = unit.tagline.split(' ').slice(0, 5).join(' ').replace("/", "%2F");

                // remove the visual loading indicators
                RES.indicateLoading("#RES-li-THIRD_BUTTON-airbnb-hiver", false, "", "", true);

                // open the window
                window.open(`https://mail.google.com/mail/u/${settings.THIRD_GMAIL_NUM}/#search/label:Hiver-airbnb ${guest.firstName} (${reservation.external} OR "${unitTaglineShort}")`, "_blank");
              });
            } else {
              unitTaglineShort = unit.tagline.split(' ').slice(0, 5).join(' ').replace("/", "%2F");

              // open the window
              window.open(`https://mail.google.com/mail/u/${settings.THIRD_GMAIL_NUM}/#search/label:Hiver-airbnb ${guest.firstName} (${reservation.external} OR "${unitTaglineShort}")`, "_blank");
            }
          }
        };

        var guest = {
          email: "",
          firstName: "",
          lastName: "",
          phone: "",
          phone2: ""
        };


        // IMPORTANT UNIT/GUEST/RESERVATION VARIABLES

        // fix for the new ROFO update that broke the scripts
        $("#r").parent().attr('id', 'qform');

        unit.id = parseInt($("#unitID").val());
        unit.name = $("body > p:nth-of-type(1) > a:nth-of-type(1)").text();
        unit.code = $("body > p:nth-of-type(1) > a:nth-of-type(2)").text();
        unit.lomId = parseInt($("#lomID").val());
        reservation.id = parseInt($("#resID").val());
        reservation.type = parseInt($("#Type").val());
        reservation.source.raw = $("body > p:nth-of-type(1) > strong:nth-of-type(1)").html().replace(/Source:&nbsp;/g, "");
        reservation.source.num = parseInt($("select[name='reservation_source_id'] option:selected").val());
        reservation.created.raw = $($("body > p:nth-of-type(1) > a:nth-of-type(2)")[0].nextSibling).text();
        reservation.created.timestamp = reservation.created.raw.substring(reservation.created.raw.indexOf("), created on ") + 14, reservation.created.raw.indexOf(" by "));
        reservation.created.date = reservation.created.timestamp.substring(0, reservation.created.timestamp.indexOf(" "));
        reservation.created.time = reservation.created.timestamp.substring(reservation.created.timestamp.indexOf(" "), reservation.created.timestamp.length);
        reservation.author = reservation.created.raw.substring(reservation.created.raw.indexOf(" by ") + 4, reservation.created.raw.lastIndexOf("."));
        reservation.nights.first = $("#FirstNight").val();
        reservation.nights.last = $("#qform > div[style^='opacity: .7'] > table > tbody > tr:nth-of-type(5) > td:nth-of-type(3) > input").val();
        reservation.nights.checkOut = $("#qform > div[style^='opacity: .7'] > table > tbody > tr:nth-of-type(6) > td:nth-of-type(2)").text();
        reservation.cancel.raw = $("#qform > div.alert-info:nth-of-type(1)").text().trim();
        reservation.gridLink = $("body > p:nth-of-type(1) > a[href*='resgrid.php']").attr("href");
        guest.firstName = $("#FirstName").val();
        guest.lastName = $("#LastName").val();
        guest.email = $("#Email").val();
        guest.phone = $("#Phone").val();
        guest.phone2 = $("#Phone2").val();

        // if cancelled, get cancel date
        if (reservation.cancel.raw.indexOf("This reservation was cancelled by on ") !== -1) {
          reservation.cancel.date = reservation.cancel.raw.substring(37, reservation.cancel.raw.indexOf(" ", 37));
        }

        // parse out the source and external ID number (if there is one)
        if (reservation.source.raw.indexOf("External # ") !== -1) {
          reservation.source.name = reservation.source.raw.substring(0, reservation.source.raw.indexOf(" (External"));
          reservation.external = reservation.source.raw.substring(reservation.source.raw.indexOf("External # ") + 11, reservation.source.raw.indexOf(")"));
        } else {
          reservation.source.name = reservation.source.raw;
        }


        // MAIN HTML

        var elSettings = "",
        elThird = "";

        elSettings = `<span title="ResEdit Suite Settings" style="display: inline-block; vertical-align: middle;"><button id="RES-btn-pop-settings" class="btn-link" role="button" data-toggle="popover" data-container="#RES-navbar-collapse" data-trigger="click" data-placement="bottom" data-title="null"><i class="fas fa-cog"></i></button></span>`;
        elThird = `<span id="RES-span-THIRD_BUTTON" class="dropdown res hidden">
            <button id="RES-btn-THIRD_BUTTON" class="btn btn-default navbar-btn dropdown-toggle btn-sm" disabled data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-fw fa-hands-helping"></i> 3rd Party <span class="caret"></span></button>
            <ul id="RES-ul-THIRD_BUTTON" class="dropdown-menu res">
            </ul>
          </span>`;


        // AUGMENTATION

        // inject our supplementary navbar elements, modals, and pad the page
        $("#RES-navbar-collapse").prepend(elSettings);
        $("#RES-navbar-collapse").append(elThird);

        // load and populate our settings configuration
        RES.settings.init();


        // SETTING: PORTAL IN NEW WINDOW

        if (settings.PORTAL_NEW_WIN === true) {
          let portalHTML = "";

          // create a new button, to replace the old one
          portalHTML = `<div class="res-only"><a target="_blank" href="/admin/dashboard/reservation/tripPortalGateway?reservationId=${reservation.id}&utm_campaign=trip-portal-login&utm_source=resedit" class="btn trip-portal-link res-only" role="button">View Guest Portal</a></div>`;

          // hide the old button, inject the new one
          $("#trip-portal-link").hide().before(portalHTML);

          // if the reservation is a Vacasa/Owner hold, disable some menu items
          if (reservation.type !== 1) {
            $(".res-only").addClass("disabled");
          }
        }


        // SETTING: SCROLLING EMAIL LOG

        if (settings.EMAIL_SCROLL === true) {
          let emailSubjects = {};

          // wrap the Email Log in a style div, and give it a scrolling overflow with a max height
          $("div > h4:contains('Email Log')").next("table").wrap(`<div id="email-wrapper" style="max-height: 400px !important; overflow-y: auto !important; overflow-x: hidden !important;"></div>`);

          // this snippet corrects a bug where if an email doesn't have a subject line, it isn't clickable in the log
          emailSubjects = $("#email-wrapper > table > tbody > tr > td:nth-of-type(2) > a");
          for (let i = 0; i < emailSubjects.length; i++) {
            if (emailSubjects[i].text === " ") {
              emailSubjects[i].append("(no subject)");
            }
          }

        }


        // SETTING: MAX REFUND BUTTON

        if (settings.MAX_REFUND === true) {
          let refundAmounts = {},
            maxAmount = "";

          // create a function to fill in the max value for each individual transaction
          $("head").append(
            `<script type="text/javascript">
                function setMaxVal( inputnum, maxval ) {
                  $( "#RES-btn-max-" + inputnum ).prev().val( maxval );
                }
              </script>`
          );

          // create an object containing each transaction allowing for a refund
          refundAmounts = $("form.payment-credit-form > div.input-group > input[name|='amount']");

          // iterate through each refundable transaction
          for (let i = 0; i < refundAmounts.length; i++) {
            // if the input isn't disabled, add a max button next to it
            if ($(refundAmounts[i]).prop("disabled", false)) {
              maxAmount = $(refundAmounts[i]).attr("max");
              $(refundAmounts[i]).attr("style", "min-width: 94px;");
              $(refundAmounts[i]).after(`<SPAN id="RES-btn-max-refund${i}" class="input-group-btn"><DIV class="btn btn-default" onclick="setMaxVal( 'refund${i}', '${maxAmount}')">Max</DIV></SPAN>`);
            }
          }

          // now create an object containing each OLD transaction allowing for a refund
          // OLD meaning before the new payment system was rolled out
          refundAmounts = $("form.form > div.input-group > input.form-control[name|='refundAmount']");

          // iterate through each OLD refundable transaction
          for (let i = 0; i < refundAmounts.length; i++) {
            // if the input isn't disabled, add a max button next to it
            if ($(refundAmounts[i]).prop("disabled", false)) {
              maxAmount = $(refundAmounts[i]).attr("max");
              $(refundAmounts[i]).attr("style", "min-width: 94px;");
              $(refundAmounts[i]).after(`<SPAN id="RES-btn-max-old-refund${i}" class="input-group-btn"><DIV class="btn btn-default" onclick="setMaxVal( 'old-refund${i}', '${maxAmount}')">Max</DIV></SPAN>`);
            }
          }
        }


        // SETTING: INTERNATIONAL BANNERS

        if (settings.BANNERS_INTL === true) {

          let flowyUrl = "https://workflowy.com/s/HXWY.hhCX6IHdTP",
            mapUrl = "https://www.google.com/maps/d/u/0/viewer?mid=1TE-sbSr0xSEhJ2t7hQlz0-H6ZT9SjOYT&ll=";

          let countries = {
            BE: {
              name: "Belize",
              map: "17.189869999999996%2C-88.49765000000002&z=7",
              flowy: "#/207b69900144",
              specific: "#/42fa97c72297",
              who: "#/0dd670a23fc6",
              general: "#/a8b8e8b6a491",
              where: "#/8e3fcecf1135"
            },

            CL: {
              name: "Chile",
              map: "-35.675140000000006%2C-71.54296&z=7",
              flowy: "#/6e9a96548a3e",
              specific: "#/58b18d3abbb2",
              who: "#/ae3a4695c200",
              general: "#/2476ca2e15a4",
              where: "#/c518b96d9473"
            },

            COAN: {
              name: "Colombia",
              map: "4.57086%2C-74.29732999999999&z=7",
              flowy: "#/ae7a2318f093",
              who: "#/70eea183c49c",
              general: "#/96710704f04b",
              where: "#/ce74b242b64f"
            },

            CR: {
              name: "Cosa Rica",
              map: "9.748910000000008%2C-83.75342&z=7",
              flowy: "#/9b2ff98699fc",
              who: "#/6845b97142b7",
              general: "#/04434aa309c5",
              where: "#/001ad052fad6"
            },

            CZ: {
              name: "Czechia",
              map: "49.81749000000001%2C15.472960000000057&z=7",
              flowy: "#/e5672f25da65",
              who: "#/d7923c1b68f4",
              general: "#/b743a3c3735d",
              where: "#/d4f57dd81902"
            },

            DR: {
              name: "Dominican Republic",
              map: "18.735689999999998%2C-70.16264999999999&z=8",
              flowy: "#/06d488d1ec32",
              who: "#/165fb776d424",
              general: "#/3e7b087f092d",
              where: "#/ed0b91ae3be1",
              idTicket: true
            },

            FR: {
              name: "France",
              map: "46.22762999999999%2C2.21374000000003&z=7",
              flowy: "#/a4bcf24da8a9",
              who: "#/9fb4aad45085",
              general: "#/9c6835a5cdca",
              where: "#/70621538170b"
            },

            HO: {
              name: "Honduras",
              map: "15.199990000000007%2C-86.24189999999999&z=7",
              flowy: "#/e30793de16c7",
              who: "#/b4776ee7e855",
              general: "#/3e8781d65885",
              where: "#/0cf315e4071e"
            },

            HU: {
              name: "Hungary",
              map: "47.16249%2C19.503299999999967&z=7",
              flowy: "#/6a36d231c15b",
              who: "#/06afef1eb754",
              general: "#/6776ad6f5393",
              where: "#/5348504c07bc"
            },

            IT: {
              name: "Italy",
              map: "41.871929999999985%2C12.567369999999983&z=7",
              flowy: "#/43cb3258440d",
              specific: "#/78386fa02b45",
              who: "#/d1087b7fe3ee",
              general: "#/bca345816906",
              where: "#/54fe4fc383f7"
            },

            MX: {
              name: "Mexico",
              map: "23.6345%2C-102.55277999999998&z=6",
              flowy: "#/d6921a7baa36",
              specific: "#/04e30c871b54",
              who: "#/02f520c6b56b",
              general: "#/715f7e62e7e7",
              where: "#/187af7837b5d"
            },

            NI: {
              name: "Nicaragua",
              map: "12.865409999999995%2C-85.20722&z=7",
              flowy: "#/fef0c1f3bb68",
              who: "#/6412cc1318b5",
              general: "#/0877cbb2a647",
              where: "#/a2b0810344e1"
            },

            SA: {
              name: "South Africa",
              map: "-30.55948000000001%2C22.9375&z=5",
              flowy: "#/00abb3bef7f7",
              who: "#/68f73ed85238",
              general: "#/7954f6980700",
              where: "#/a9a060997677"
            },

            SP: {
              name: "Spain",
              map: "40.46366%2C-3.7492200000000366&z=7",
              flowy: "#/e3a68d188f42",
              who: "#/013ad64c5d26",
              general: "#/327c59ed249b",
              where: "#/65b64050f876"
            },

            SW: {
              name: "Switzerland",
              map: "46.81818000000001%2C8.227509999999938&z=7",
              flowy: "#/1b0c0e26ef3a",
              who: "#/b7a879fbc3c8",
              general: "#/84290daee96f",
              where: "#/a09ff71e4635"
            },

            UY: {
              name: "Uruguay",
              map: "-32.52276999999997%2C-55.765829999999994&z=7",
              flowy: "#/7bbf56c63a60",
              who: "#/a3fb59854103",
              general: "#/389d7d9471f4",
              where: "#/5fe654f94707"
            }
          };

          function returnBanner(prefix) {

            let specific = "";

            if ("specific" in countries[prefix]) {
              specific = `<li role="presentation"><a type="button" target="_blank" href="${flowyUrl}${countries[prefix].specific}">Vacasa-Specific Info <span class="fas fa-fw fa-external-link-square-alt"></span></a></li>`;
            }

            // if (countries[prefix].idTicket === true) {
            //   $("a[href$='&contract=acknowledge']:contains('mark as received')").attr("id", "RES-contract-link");

            //   $(document).on("click", "#RES-contract-link", function (e) {
            //     if (confirm(`${countries[prefix].name} reservations require a copy of the guest ID to be returned along with the contract.\n\nClick OK if the guest included a copy of their ID, to mark the contract received and then be taken to a new ticket to attach the ID to.\n\nClick Cancel if the ID has not yet been received.`)) {
            //       window.open(`/admin/dashboard/tickets/editMaintenance?UnitID=${unit.id}&ReservationID=${reservation.id}&desc=Guest%20ID%20-%20${guest.lastName}%20-%20Reservation%20%23%20${reservation.id}&details=Attached%20is%20the%20guest%20ID.%20Contract%20has%20been%20marked%20received.`, "_blank");
            //     } else {
            //       return false;
            //     }
            //   });
            // }

            let bannerHtml =
              `<div class="alert alert-warning">
              <div style="margin-bottom: 15px;">
                <p>This is an international reservation for <strong>${countries[prefix].name}</strong>.</p><p>Please consult the International Ops memo and/or the Global Map before making alternations or creating a ticket to local staff.</p>
              </div>
              <ul class="nav nav-pills pills-warning">
                ${specific}
                <li role="presentation"><a type="button" target="_blank" href="${flowyUrl}${countries[prefix].who}">Who to Contact <span class="fas fa-fw fa-sm fa-external-link-alt"></span></a></li>
                <li role="presentation"><a type="button" target="_blank" href="${flowyUrl}${countries[prefix].general}">Country Info <span class="fas fa-fw fa-sm fa-external-link-alt"></span></a></li>
                <li role="presentation"><a type="button" target="_blank" href="${flowyUrl}${countries[prefix].where}">Unit Locations <span class="fas fa-fw fa-sm fa-external-link-alt"></span></a></li>
                <li role="presentation"><a type="button" target="_blank" href="${mapUrl}${countries[prefix].map}">Global Map <span class="fas fa-fw fa-sm fa-external-link-alt"></span></a></li>
              </ul>
            </div>`;

            return bannerHtml;

          };

          $("body > div.alert.alert-warning:contains('This reservation is a European booking.')").remove();

          if (unit.code.substring(0, 2) in countries) {
            let codePrefix = unit.code.substring(0, 2);
            $("#qform").before(returnBanner(codePrefix));
          } else if (unit.code.substring(0, 4) in countries) {
            let codePrefix = unit.code.substring(0, 4);
            $("#qform").before(returnBanner(codePrefix));
          }

        }


        // SETTING: THIRD PARTY BANNERS

        if (settings.BANNERS_THIRD === true) {

          let banners = {
            airbnb: {
              name: `Airbnb`,
              alter: `Guests can make changes to their reservation by going to their Airbnb Dashboard > Your Trips > Change or Cancel, Airbnb CS number is 855-424-7262.`,
              cancel: `Guests can cancel their reservation by going to their Airbnb Dashboard > Your Trips > Change or Cancel, Airbnb CS number is 855-424-7262.`,
              cancellations: `<dt>Within 24 hours</dt>
                <dd>Airbnb Grace Period: Guests may cancel themselves via AirBnb (Dashboard > Your Trips > Change or Cancel) and will receive an automatic full refund if cancellation is within 48 hours of booking AND the check-in date is greater than 14 days away; BOTH criteria must apply.</dd>
                <dd>We can still make exceptions for a full refund within 24 hours of booking when within 14 days of arrival - Guests can cancel themselves via AirBnb (Dashboard > Your Trips > Change or Cancel) and will be quoted a 50% refund. Once 3rd party team receives the cancellation notification, they will send the other 50% (minus Airbnb's service fee).</dd>
                <dt>Outside of 30 days</dt>
                <dd>Guests may cancel themselves via AirBnB (Dashboard > Your Trips > Change or Cancel) and will receive a refund of the cleaning fee and 50% refund of rent. This option is available to them up until 7 days prior to their check-in date (ie. 4 PM on 12/24 if check-in is 12/31).</dd>
                <dt>Within 30 days</dt>
                <dd>Guests may cancel themselves via AirBnb (Dashboard > Your Trips > Change or Cancel) and will receive a refund of the cleaning fee and 50% refund of rent. This option is available to them up until 7 days prior to their check-in date (ie. 4 PM on 12/24 if check-in is 12/31). Once they are within 7 days of check-in they will only receive a refund of the cleaning fee and nothing else.</dd>`,
              emails: `<dt>Early Arrival</dt>
                <dd>Guests do not receive the early check-in email. If it is available you can inform the guest.</dd>
                <dt>Late Departure</dt>
                <dd>Guests do not receive the email. If available consult with 3rd party team to add.</dd>
                <dt>Rental Agreements</dt>
                <dd>AirBnB guests do not receive the rental agreement and we do not require them to sign them. If you see a rental agreement not acknowledge you can hit "contract received".</dd>
                <dt>Confirmation</dt>
                <dd>AirBnB guests do not receive our confirmation email but rather receive one from AirBnB directly. This email will not contain any information included in the "warning" portion of the unit notes.</dd>
                <dt>Check-in</dt>
                <dd>All AirBnB guests receive our check-in email and have access to their Trip Portal.</dd>`,
              fees: `<dt>Pet Fee</dt>
                <dd>Airbnb guests are not being charged for the pet fee. The pet should still be added to the reservation and finances adjusted back to the previous amounts.</dd>
                <dt>Pool Heating Fee</dt>
                <dd>Guests must request to add heating and pay via AirBnB. We follow the same pool heating policies as any other reservation. Must be at least a 3 night stay and LOM be given at least 48 hr notice.</dd>
                <dt>Trip Protection</dt>
                <dd>This is not offered via the AirBnB site and is not available for AirBnB guests to purchase; Airbnb customer support will mediate regarding any extenuating circumstances.</dd>`,
              refunds: `<dd>Refund decisions still need to be decided upon by the LOM and/or GM. GSEs can be created and sent out. Once a refund is decided upon a 3rd party agent will need to process it via the AirBnB extranet.</dd>`,
              altering: `<dt>Removing Nights</dt>
                <dd>Guests may request to adjust dates via AirBnB (Dashboard > Your Trips > Change or Cancel). No changes can be made within 48 hours of check-in time. Once a reservation has been altered, the original reservation will be canceled and a new one will be created. Please search by the guest's name to find it.</dd>
                <dd>DO NOT GUARANTEE a removal of nights with a refund if a guest is within 30 days of their check-in. They can put the request in via AirBnB and it will be evaluated at that point.</dd>
                <dt>Adding Nights</dt>
                <dd>Guests may request to add nights via AirBnB (Dashboard > Your Trips > Change or Cancel). No changes can be made within 48 hours of check-in time. Once a reservation has been altered, the original reservation will be canceled and a new one will be created. Please search by the guest's name to find it.</dd>
                <dd>If a guest is calling to add nights within 48 hours of their check-in time or if they are already in the home you will need to add the nights on our side and obtain their credit card to charge them for the additional nights.</dd>
                <dt>Moving Dates</dt>
                <dd>Guests may request to adjust dates via AirBnB (Dashboard > Your Trips > Change or Cancel). No changes can be made within 48 hours of check-in time. Once a reservation has been altered, the original reservation will be canceled and a new one will be created. Please search by the guest's name to find it.</dd>
                <dd>DO NOT GUARANTEE a guest that they can move their dates if they are within 30 days of their check-in. They can put the request in via AirBnB and it will be evaluated at that point.</dd>
                <dt>Changing Units</dt>
                <dd>Guests may request to change homes via AirBnB (Dashboard > Your Trips > Change or Cancel). No changes can be made within 48 hours of check-in time. Once a reservation has been altered, the original reservation will be canceled and a new one will be created. Please search by the guest's name to find it.</dd>
                <dd>DO NOT GUARANTEE a guest that they can change units if they are within 30 days of their check-in. They can put the request in via AirBnB and it will be evaluated at that point.</dd>
                <dt>Forced Moves</dt>
                <dd>Forced moves should be handled as usual up until the guest decides on a home they want to move to or decide to cancel. At that point please touch base with a 3rd party agent. If the home is listed on AirBnB we would like to process that change via the extranet (if the check-in is more than 48 hours away). If the guest would like to cancel please forward the reservation to a 3rd party agent and they will process the cancellation through the Airbnb extranet.</dd>`
            },

            bdc: {
              name: `Booking.com`,
              alter: `Process as normal in our system.`,
              cancel: `Guests can cancellation their reservation by visiting Booking.com or calling their CS number at 888-850-3958.`,
              cancellations: `<dt>Within 24 hours</dt>
                <dd>Guests may cancel themselves via Booking.com (phone or website). 3rd party team will be notified via an email from to authorize a full refund. If a Booking.com agent is calling you may authorize the refund yourself.</dd>
                <dt>Outside of 60 days</dt>
                <dd>Guests may cancel themselves via Booking.com (phone or website) for a full refund if their check-in is outside of 60 days.</dd>
                <dt>Within 60 days</dt>
                <dd>If a guest cancels within 60 days of the check-in they only receive a refund of the fees listed on their Booking.com reservation. Please have them contact booking.com directly to cancel.</dd>`,
              fees: `<dt>Pet Fee</dt>
                <dd>Process as normal.</dd>
                <dt>Pool Heating Fee</dt>
                <dd>Process as normal. We follow the same pool heating policies as any other reservations. Must be at least a 3 night stay and LOM be given at least 48 hr notice.</dd>
                <dt>Trip Protection</dt>
                <dd>Since we collect the guests credit card information they are able to purchase trip protection and we can add it to the card on file. All rules/regulations regarding trip protection apply.</dd>`,
              refunds: `<dd>Refund decisions still need to be decided upon by the LOM and/or GM. GSEs can be created and sent out. Once a refund is decided upon process as normal.</dd>`,
              altering: `<dt>Removing Nights</dt>
                <dd>Process as normal if more than 30 days from check-in. Advise guests that the new dates will no longer match their itinerary on Booking.com. If within 30 days from check-in please consult 3rd party team.</dd>
                <dt>Adding Nights</dt>
                <dd>Process as normal. Advise guests that the new dates will no longer match their itinerary on Booking.com.</dd>
                <dt>Moving Dates</dt>
                <dd>Process as normal if more than 30 days from check-in. Advise guests that the new dates will no longer match their itinerary on Booking.com. If within 30 days from check-in please consult 3rd party team.</dd>
                <dt>Changing Units</dt>
                <dd>Process as normal if more than 30 days from check-in. Advise guests that the new dates will no longer match their itinerary on Booking.com. If within 30 days from check-in please consult 3rd party team.</dd>
                <dt>Forced Moves</dt>
                <dd>Process as normal unless a guest decides to cancel. If a guest decides to cancel please advise them that a cancellation authorization will be sent to them and they will need to accept it so we can refund them in full. Then immediately reach out to a 3rd party agent to sent that authorization. If a guest chooses a different home advise them their Booking.com itinerary will not reflect this but to not cancel the original reservation on Booking.com.</dd>`
            },

            expedia: {
              name: `Expedia`,
              alter: `You can process any changes of dates/unit the same as we would for a Vacasa reservation.`,
              cancel: `Guests will need to cancel via Expedia - they can do so by calling 800-397-3342 or visiting Expedia.com - if within 24 hours of booking please reach out to SS or 3rd Party Agent team.`,
              cancellations: `<dt>Within 24 hours</dt>
                <dd>We will allow guests to cancel within 24 hours of booking. In order to do this please reach out to a Senior Specialist or 3rd Party Agent and they will be able to reject this reservation from the Expedia extranet.</dd>
                <dt>Outside of 60 days</dt>
                <dd>Our cancellation policy on Expedia allows guests to cancel 60 days out with a full refund minus 10% penalty fee. The guest will need to reach out to Expedia in order to initiate this cancellation.</dd>
                <dt>Within 60 days</dt>
                <dd>Cancellation within 60 days will not be eligible for a refund and the guest will need to contact Expedia directly to cancel. Only if it is an extenuating circumstance should you need to consult a 3rd party agent; otherwise stick with no refund.</dd>`,
              fees: `<dt>Pet Fee</dt>
                <dd>Guests are required to pay the same pet fee as regular Vacasa reservations and this fee can be charged to the card on file.</dd>
                <dt>Pool Heating Fee</dt>
                <dd>Guests are required to pay any pool heating fees; these can be charged to the card on file.</dd>
                <dt>Trip Protection</dt>
                <dd>Since we collect the guests credit card information they are able to purchase trip protection and we can add it to the card on file. All rules/regulations regarding trip protection apply.</dd>`,
              refunds: `<dd>All refunds can be processed as normal to the card on file.</dd>
                <dd>Refund decisions still need to be made by the LOM and/or GM. GSEs can be created and sent out. Once a refund is decided upon process as normal.</dd>`,
              altering: `<dt>Removing Nights</dt>
                <dd>Process as normal to the card on file if more than 30 days from check-in. Advise guests that the new dates will no longer match their itinerary on Expedia.com. If within 30 days from check-in please consult 3rd party team.</dd>
                <dt>Adding Nights</dt>
                <dd>Process as normal to card on file. Advise guests that the new dates will no longer match their itinerary on Expedia.com.</dd>
                <dt>Moving Dates</dt>
                <dd>Process as normal if more than 30 days from check-in. Make sure rent and fees look right. If they don't then pull accurate numbers from the Vacasa website. Advise guests that the new dates will no longer match their itinerary on Expedia.com. If within 30 days from check-in please consult 3rd party team.</dd>
                <dt>Changing Units</dt>
                <dd>Process as normal if more than 30 days from check-in. Make sure rent and fees look right. If they don't then pull accurate numbers from the Vacasa website. Advise guests that the new dates will no longer match their itinerary on Expedia.com. If within 30 days from check-in please consult 3rd party team.</dd>
                <dt>Forced Moves</dt>
                <dd>Process as normal unless a guest decides to cancel. If a guest decides to cancel please reach out to a 3rd party agent to call in the cancellation. If a guest chooses a different home advise them their Expedia.com itinerary will not reflect this but to not cancel the original reservation on Expedia.com.</dd>`
            },

            fkta: {
              name: `Flipkey/Tripadvisor`,
              alter: `To remove nights/change dates/change units the guest will need to put the request in via FK/TA - They can do so by logging into their FK/TA account or calling 877-354-7539.`,
              cancel: `Guests will need to cancel via FK/TA - They can do so by calling 877-354-7539 or visiting Flipkey.com.`,
              cancellations: `<dt>Within 24 hours</dt>
                <dd>The guest must cancel through Tripadvisor/Flipkey. If within 24 hours and more than 60 days away from their check-in date, they will receive a full refund including the TA/FK service fee.</dd>
                <dd>If within 24 hours and less than 60 days away from their check-in date, TA/FK will keep their booking fee and automatically refund 50% of the reservation total. The guest can ask for an exception to the refund amount and we will approve a refund of the remaining 50% of the reservation (still excluding the TA/FK service fee).</dd>
                <dt>Outside of 30 days</dt>
                <dd>Guests may cancel themselves via TripAdvisor / FlipKey. They will receive a 50% refund. This option expires 28 days prior to their check-in date.</dd>
                <dt>Within 30 days</dt>
                <dd>No refunds within 28 days of check-in. Only if it is an extenuating circumstance should you need to consult a 3rd party agent; otherwise stick with no refund and the guest will need to cancel themselves via TripAdvisor or contact TripAdvisor directly.</dd>`,
              fees: `<dt>Pet Fee</dt>
                <dd>Collect credit card info and then process as normal.</dd>
                <dt>Pool Heating Fee</dt>
                <dd>Collect credit card info if still needed and then process as normal.. We follow the same pool heating policies as any other reservations. Must be at least a 3 night stay and LOM be given at least 48 hr notice.</dd>
                <dt>Trip Protection</dt>
                <dd>This is not offered via TripAdvisor/Flipkey and is not available for TA/FK guests to purchase.</dd>`,
              refunds: `<dd>Refunds must be sent by check. Please collect guest mailing address and make ticket for finance.</dd>
                <dd>Refund decisions still need to be decided upon by the LOM and/or GM. GSEs can be created and sent out.</dd>`,
              altering: `<dt>Removing Nights</dt>
                <dd>Advise the guest to put this request through via Tripadvisor/Flipkey then notify a 3rd Party Agents to they can keep an eye out for it.</dd>
                <dd>DO NOT GUARANTEE a removal of nights with a refund if a guest is within 30 days of their check-in. They can put the request in via TA/FK and it will be evaluated at that point.</dd>
                <dt>Adding Nights</dt>
                <dd>You will have to manually add the appropriate amount of rent and taxes to the charges; just adding the nights will make all the totals go wrong. You will also need to collect their credit card and then process as normal.</dd>
                <dt>Moving Dates</dt>
                <dd>Advise the guest to put this request through via Tripadvisor/Flipkey then notify a 3rd Party Agents to they can keep an eye out for it.</dd>
                <dd>DO NOT GUARANTEE a removal of nights with a refund if a guest is within 30 days of their check-in. They can put the request in via TA/FK and it will be evaluated at that point.</dd>
                <dt>Changing Units</dt>
                <dd>Advise the guest to put this request through via Tripadvisor/Flipkey then notify a 3rd Party Agents to they can keep an eye out for it.</dd>
                <dd>DO NOT GUARANTEE a removal of nights with a refund if a guest is within 30 days of their check-in. They can put the request in via TA/FK and it will be evaluated at that point.</dd>
                <dt>Forced Moves</dt>
                <dd>Process as normal unless a guest decides to cancel. If a guest decides to cancel please consult a 3rd Party Agent to get this processed. If a guest chooses to change homes advise them their Tripadvisor/Flipkey itinerary will no longer match.</dd>`
            },

            glamping: {
              name: `GlampingHub`,
              alter: `Guests will need to contact GlampingHub directly - They can do so by calling them at 415-800-3004, or visiting their profile on GlampingHub.`,
              cancellations: `<dt>Within 24 hours</dt>
                <dd>The guest must cancel by calling or emailing Glamping Hub and we will approve a full refund. 3rd party agents can also contact Glamping Hub's support department to authorize a full refund on the guest's behalf.</dd>
                <dt>Outside of 30 days</dt>
                <dd>Guests will receive a 50% refund when they cancel at least 30 days prior to check in.</dd>
                <dt>Within 30 days</dt>
                <dd>Within 30 days of check-in, no refund will be given. Cancellations made during the stay will be refunded at the hosts' discretion.</dd>`,
              fees: `<dt>Pet Fee</dt>
                <dd>Collect credit card info and then process as normal.</dd>
                <dt>Pool Heating Fee</dt>
                <dd>Collect credit card info if still needed and then process as normal.. We follow the same pool heating policies as any other reservations. Must be at least a 3 night stay and LOM be given at least 48 hr notice.</dd>
                <dt>Trip Protection</dt>
                <dd>This is not offered via Glamping Hub and is not available for GH guests to purchase.</dd>`,
              refunds: `<dd>Refunds must be sent by check. Please collect guest mailing address and make ticket for finance.</dd>
                <dd>Refund decisions still need to be decided upon by the LOM and/or GM. GSEs can be created and sent out.</dd>`,
              altering: `<dt>Removing Nights</dt>
                <dd>Advise the guest to contact Glamping Hub about adjusting their reservation so that the card they used can be refunded accordingly (if a refund applies).</dd>
                <dd>DO NOT GUARANTEE a removal of nights with a refund if a guest is within 30 days of their check-in. They can put the request in via GH and it will be evaluated at that point.</dd>
                <dt>Adding Nights</dt>
                <dd>Collect a credit card and process as normal. Keep a close eye on the rent and taxes when making any changes - you may need to manually adjust the reservation to the correct amount.</dd>
                <dt>Moving Dates</dt>
                <dd>Process as normal if greater than 30 days from check-in and collect a credit card for any additional costs. Keep a close eye on rent/fees/tax when making any changes - you may need to manually adjust the reservation to the correct amount.</dd>
                <dt>Changing Units</dt>
                <dd>Process as normal if greater than 30 days from check-in and collect a credit card for any additional costs. Keep a close eye on rent/fees/tax when making any changes - you may need to manually adjust the reservation to the correct amount.</dd>
                <dt>Forced Moves</dt>
                <dd>Process as normal unless a guest decides to cancel. If a guest decides to cancel please consult a 3rd Party Agent to get this processed. If a guest chooses to change homes advise them their Glamping Hub itinerary will no longer match.</dd>`
            },

            google: {
              name: `Google`,
              alter: `Changes and refunds can be handled by anyone.`,
              cancel: `Cancellations need to go through the 3rd Party Channel team.`,
              cancellations: `<dt>Within 24 hours</dt>
                <dd>We will allow guests to cancel within 24 hours of booking. In order to do this please reach out to a 3rd Party Specialist.</dd>
                <dt>Outside of 60 days</dt>
                <dd>Outside of 60 days of the check-in a guest can cancel free of charge. A 3rd Party Specialist will have to process this cancellation.</dd>
                <dt>Within 60 days</dt>
                <dd>Within 60 days of the check-in no refund is offered. If a guest wants to cancel anyways please contact a 3rd Party Specialist.</dd>`,
              fees: `<dt>Pet Fee</dt>
                <dd>Guests are required to pay the same pet fee as regular Vacasa reservations and this fee can be charged to the card on file.</dd>
                <dt>Pool Heating Fee</dt>
                <dd>Guests are required to pay any pool heating fees; these can be charged to the card on file.</dd>
                <dt>Trip Protection</dt>
                <dd>Since we collect the guests credit card information they are able to purchase trip protection and we can add it to the card on file. All rules/regulations regarding trip protection apply.</dd>`,
              refunds: `<dd>Refund decisions still need to be decided upon by the LOM and/or GM. GSEs can be created and sent out. Once a refund is decided upon process as normal.</dd>`,
              altering: `<dt>Removing Nights</dt>
                <dd>Process as normal if more than 30 days from check-in. Make sure rent and fees look right. If they don't then pull accurate numbers from the Vacasa website.</dd>
                <dt>Adding Nights</dt>
                <dd>Process as normal. Make sure rent and fees look right. If they don't then pull accurate numbers from the Vacasa website.</dd>
                <dt>Moving Dates</dt>
                <dd>Process as normal if more than 30 days from check-in. Make sure rent and fees look right. If they don't then pull accurate numbers from the Vacasa website.</dd>
                <dt>Changing Units</dt>
                <dd>Process as normal if more than 30 days from check-in. Make sure rent and fees look right. If they don't then pull accurate numbers from the Vacasa website.</dd>
                <dt>Forced Moves</dt>
                <dd>Process as normal unless a guest decides to cancel. If a guest decides to cancel please contact a 3rd Party Specialist so they can process that cancellation.</dd>`
            }
          }

          function returnBanner(channel) {

            let cancel = "";

            let emails = {
              pill: "",
              section: ""
            };

            if ("cancel" in banners[channel]) {
              cancel = `<tr><td><strong>Cancellation</strong></td><td>${banners[channel].cancel}</td></tr>`;
            }

            if ("emails" in banners[channel]) {
              emails.pill = `<li role="presentation"><a type="button" href="#" onclick="toggleCollapse('#RES-div-BANNERS_THIRD-emails', $(this));" title="Expand Section">Emails <span class="caret rotate"></span></a></li>`;
              emails.section =
                `<div id="RES-div-BANNERS_THIRD-emails" class="collapse" style="margin-top: 15px;">
                  <h4 class="text-warning">Emails</h4>
                  <dl class="list-group-item helper">
                  ${banners[channel].emails}
                  </dl>
                </div>`;
            }

            let bannerHtml =
              `<div class="alert alert-warning">
              <div style="margin-bottom: 15px;">
                <table class="panel-table">
                  <colgroup><col style="width: 160px;"></colgroup>
                  <tr><td><strong>3rd Party Reservation</strong></td><td>${banners[channel].name}</td></tr>
                  <tr><td><strong>Alterations</strong></td><td>${banners[channel].alter}</td></tr>
                  ${cancel}
                </table>
              </div>
              <div>
                <ul class="nav nav-pills pills-warning">
                  <li role="presentation"><a type="button" href="#" onclick="toggleCollapse('#RES-div-BANNERS_THIRD-cancellations', $(this));" title="Expand Section">Cancellations <span class="caret rotate"></span></a></li>
                  ${emails.pill}
                  <li role="presentation"><a type="button" href="#" onclick="toggleCollapse('#RES-div-BANNERS_THIRD-extra-fees', $(this));" title="Expand Section">Extra Fees <span class="caret rotate"></span></a></li>
                  <li role="presentation"><a type="button" href="#" onclick="toggleCollapse('#RES-div-BANNERS_THIRD-refunds', $(this));" title="Expand Section">Refunds <span class="caret rotate"></span></a></li>
                  <li role="presentation"><a type="button" href="#" onclick="toggleCollapse('#RES-div-BANNERS_THIRD-altering', $(this));" title="Expand Section">Altering a Reservation <span class="caret rotate"></span></a></li>
                </ul>
              </div>
              <div id="RES-div-BANNERS_THIRD-cancellations" class="collapse" style="margin-top: 15px;">
                <h4 class="text-warning">Cancellations</h4>
                <dl class="list-group-item helper">
                  ${banners[channel].cancellations}
                </dl>
              </div>
              ${emails.section}
              <div id="RES-div-BANNERS_THIRD-extra-fees" class="collapse" style="margin-top: 15px;">
                <h4 class="text-warning">Extra Fees</h4>
                <dl class="list-group-item helper">
                  ${banners[channel].fees}
                </dl>
              </div>
              <div id="RES-div-BANNERS_THIRD-refunds" class="collapse" style="margin-top: 15px;">
                <h4 class="text-warning">Refunds</h4>
                <dl class="list-group-item helper">
                  ${banners[channel].refunds}
                </dl>
              </div>
              <div id="RES-div-BANNERS_THIRD-altering" class="collapse" style="margin-top: 15px;">
                <h4 class="text-warning">Altering a Reservation</h4>
                <dl class="list-group-item helper">
                  ${banners[channel].altering}
                </dl>
              </div>
            </div>`;

            return bannerHtml;

          };

          // add a function to toggle our collapsible sections, and de/activate the nav-pills
          $("head").append(
            `<script type="text/javascript">
              function toggleCollapse( id, pill ) {
                $( id ).slideToggle( 400 );
                $( pill ).toggleClass( "active" );
                $( pill ).children( "span" ).toggleClass( "rotate" );
                return false;
              }
            </script>`
          );

          // determine the creation source
          switch (reservation.source.num) {
            case 8: // Airbnb
            case 9: // also Airbnb
              $("#qform").before(returnBanner("airbnb"));
              break;
            case 10: // Flipkey/Tripadvisor
              $("#qform").before(returnBanner("fkta"));
              break;
            case 12: // Booking.com
            case 13: // also Booking.com
              $("#qform").before(returnBanner("bdc"));
              break;
            case 14: // Expedia
            case 15: // also Expedia
              $("#qform").before(returnBanner("expedia"));
              break;
            case 63: // GlampingHub
              $("#qform").before(returnBanner("glamping"));
              break;
            case 69: // Google
              $("#qform").before(returnBanner("google"));
              break;
            default:
              break;
          }

          // delete the vanilla banners
          $("body > div.alert.alert-warning:contains('This is a 3rd Party Channel reservation')").remove();
          $("body > div.alert.alert-warning:contains('This is an Airbnb Reservation')").remove();
          $("body > div.alert.alert-warning:contains('This is a'):contains('Booking.com reservation:')").remove();
          $("body > div.alert.alert-warning:contains('This is a FlipKey/TripAdvisor')").remove();
          $("body > div.alert.alert-warning:contains('This is a GlampingHub reservation')").remove();
          $("body > div.alert.alert-warning:contains('This is an Expedia reservation')").remove();
        }


        // SETTING: THIRD PARTY BUTTON

        if (settings.THIRD_BUTTON === true) {
          // show the button
          $("#RES-span-THIRD_BUTTON").removeClass("hidden");

          // figure out what 3rd party source the res is
          if (reservation.source.num === 12 || reservation.source.num === 13) {
            // Booking.com creation source
            $("#RES-ul-THIRD_BUTTON").append(`<li><a target="_blank" href="https://mail.google.com/mail/u/${settings.THIRD_GMAIL_NUM}/#search/label:Hiver-bookingcom ${reservation.external}">Hiver Search</a></li>`);
            $("#RES-btn-THIRD_BUTTON").prop("disabled", false);
          } else if (reservation.source.num === 8 || reservation.source.num === 9) {
            // Airbnb creation source
            $("#RES-ul-THIRD_BUTTON").append(`<li id="RES-li-THIRD_BUTTON-airbnb-hiver"><a href="#">Hiver Search</a><span class="fas fa-fw pull-right"></span></li>`);
            $("#RES-ul-THIRD_BUTTON").append(`<li role="separator" class="divider"></li>`);
            $("#RES-ul-THIRD_BUTTON").append(`<li id="RES-li-THIRD_BUTTON-agreement" class="disabled"><a href="/admin/resedit.php?r=${reservation.id}&contract=acknowledge">Acknowledge Agreement</a></li>`);
            if ($("p.list-group-item-text").text().indexOf("Acknowledged on") === -1 && $("div.alert-info").text().indexOf("This reservation was cancelled") === -1) {
              $("#RES-li-THIRD_BUTTON-agreement").removeClass("disabled");
            }

            $("#RES-btn-THIRD_BUTTON").prop("disabled", false);

            $(document).on("click", "#RES-li-THIRD_BUTTON-airbnb-hiver", function (e) {
              reservation.searchHiverAirbnb();
              return false;
            });
          } else if (reservation.source.num === 5) {
            // HomeAway creation source
            $("#RES-ul-THIRD_BUTTON").append(`<li><a target="_blank" href="https://mail.google.com/mail/u/${settings.THIRD_GMAIL_NUM}/#search/label:hiver-homeawayinquiries ${reservation.id}">Hiver Search</a></li>`);
            $("#RES-btn-THIRD_BUTTON").prop("disabled", false);
          } else if (reservation.source.num === 63) {
            // GlampingHub creation source
            $("#RES-ul-THIRD_BUTTON").append(`<li><a target="_blank" href="https://mail.google.com/mail/u/${settings.THIRD_GMAIL_NUM}/#search/label:hiver-flipkey1 ${guest.firstName.trim()} ${guest.lastName.trim()}">Hiver Search</a></li>`);
            $("#RES-btn-THIRD_BUTTON").prop("disabled", false);
          } else if (reservation.source.num === 10) {
            // Flipkey/Tripadvisor creation source
            $("#RES-ul-THIRD_BUTTON").append(`<li><a target="_blank" href="https://mail.google.com/mail/u/${settings.THIRD_GMAIL_NUM}/#search/label:hiver-flipkey1 ${reservation.external}">Hiver Search</a></li>`);
            $("#RES-btn-THIRD_BUTTON").prop("disabled", false);
          }
        }


        // SETTING: REFUND HASH REASONS

        if (settings.REFUND_HASH === true) {

          let refund_hash = {
            modalHtml: "",
            amount: 0,
            note: ""
          }

          // Owner Credit Request Calculator modal
          refund_hash.modalHtml =
            `<div class="modal fade" id="RES-rehash-modal" tabindex="-1" role="dialog" aria-labelledby="RES-rehash-modal-label">
            <div class="modal-dialog" role="document" style="width: 360px;">
              <div class="modal-content">
                <div class="modal-header alert-info">
                  <h4 class="modal-title" id="RES-rehash-modal-label">Issue a Refund</h4>
                </div>
                <div class="modal-body container-fluid">
                  <div class="col-sm-12">
                    <div class="form-group">
                        <label>Amount</label>
                        <samp id="RES-rehash-amount" class="pull-right"></samp>
                    </div>
                    <div class="form-group">
                      <label for="RES-rehash-reason">Reason</label>
                      <select id="RES-rehash-reason" class="form-control">
                        <option value="#Refund #Cancel #Full">Cancellation (Full Refund)</option>
                        <option value="#Refund #Cancel #Partial">Cancellation (Partial Refund)</option>
                        <option value="#Refund #DateAlteration">Date Alteration</option>
                        <option value="#Refund #DinnerComp">Dinner Comp</option>
                        <option value="#Refund #Discount">Discount Added</option>
                        <option value="#Refund #FM #Cancel">Forced Move (Cancel for Refund)</option>
                        <option value="#Refund #FM #Reduced">Forced Move (New Home is Less)</option>
                        <option value="#Refund #Satisfaction">Guest Satisfaction</option>
                        <option value="#Refund #VacatedEarly">Guest Vacated Early</option>
                        <option value="#Refund #AmenityLoss">Loss of Amenity</option>
                        <option value="#Refund #AmenityLoss #HotTub">Loss of Amenity (Hot Tub)</option>
                        <option value="#Refund #MissedClean">Missed Clean</option>
                        <option value="#Refund #NaturalDisaster">Natural Disaster</option>
                        <option value="#Refund #NotAsAdvertised">Not as Advertised</option>
                        <option value="#Refund #PetADA">Pet Refunded (ADA Animal)</option>
                        <option value="#Refund #PetRemoved">Pet Removed</option>
                        <option value="#Refund #PriceMatch">Price Match</option>
                        <option value="#Refund #SubparClean">Subpar Clean</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-sm-12">
                    <div class="alert alert-warning">
                      <p>For tracking purposes, it is important that refund reasons be chosen that most accurately fit the situation.</p>
                      <div id="RES-rehash-current-tags">
                        <h4>Current Tags:</h4>
                        <span></span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="modal-footer clearfix">
                  <div class="col-sm-12">
                    <button id="RES-rehash-btn-cancel" type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <button id="RES-rehash-btn-issue" type="button" class="btn btn-primary">Refund</button>
                  </div>
                </div>
              </div>
            </div>
          </div>`;

          $("body").prepend(refund_hash.modalHtml);

          $(document).on("change", "#RES-rehash-reason", function (e) {
            $("#RES-rehash-current-tags > span").html(`<pre>${$("#RES-rehash-reason").val()}</pre>`);
          });

          $(document).ready(function (e) {
            $("#RES-rehash-current-tags > span").html(`<pre>${$("#RES-rehash-reason").val()}</pre>`);
          });

          $(document).on("click", ".payment-credit-submit", function (e) {
            refund_hash.amount = $(this).parent().parent().children("input").val();
            if (refund_hash.amount !== "" && parseFloat(refund_hash.amount) !== 0) {
              $("#RES-rehash-amount").html("$" + parseFloat(refund_hash.amount).toFixed(2));
              $("#RES-rehash-modal").modal("show");
              $(this).parents("form").attr("id", "RES-rehash-form");
              return false;
            }
          });

          $(document).on("click", "#RES-rehash-btn-issue", function (e) {
            refund_hash.note = $("#RES-rehash-reason").val().replace(/#/g, "%23").replace(/ /g, "%20") + "%20Amount%3A%20" + parseFloat(refund_hash.amount).toFixed(2);
            $.get(`/admin/dashboard/reservation/addNote?reservationId=${reservation.id}&note=${refund_hash.note}`, function (data) {
              $("#RES-rehash-form").submit();
            });
          });
        }

      },


      // EDIT RESERVATION FINANCES
      // /admin/dashboard/reservation/finance/edit

      edit_finances: function () {

        let resFinanceType = "";

        resFinanceType = $("#sourcesHeader[data-title*='Finances']").attr("data-title");

        // SETTING: ORGANIZED INFO

        if (settings.ORGANIZED_INFO === true) {
          let unitLink = "",
            heights = 0;

          // save the unit link in the sources header for later, then delete header because the info is redundant
          unitLink = $("#sourcesHeader > div > table > tbody > tr:nth-child(2) > td:nth-child(2) > a").attr("href");
          $("#sourcesHeader > div").remove();

          // give everything that interests us IDs so we can better move/track them
          $("#flyout-content > div > div.row > div:nth-child(1) > div:nth-child(1) > table:nth-child(2)").attr("id", "modTableFees");
          $("#flyout-content > div > div.row > div:nth-child(2) > div:nth-child(2) > div > div > table").attr("id", "modTableTaxDistricts");
          $("#flyout-content > div > div.row > div:nth-child(1)").attr("id", "modColumnTotals");
          $("#flyout-content > div > div.row > div:nth-child(2)").attr("id", "modColumnAdjustmentsRes");

          // make information columns swap sides, for better info flow
          $("#modColumnTotals").before($("#modColumnAdjustmentsRes"));

          // group taxes with other subtotals, format them similarly, then remove empty div they used to reservation.ide in
          $("#modTableFees").after($("#modTableTaxDistricts"));
          $("#modTableTaxDistricts > thead > tr > td:nth-child(1)").html("");
          $("#modTableTaxDistricts > thead > tr").before(`<TR><TD><h3 class="finance-summary-title">Tax Districts</h3></TD><TD>Total</TD></TR>`);
          $("#modColumnAdjustmentsRes > div:nth-child(2)").remove();

          // time to create useful links in the reservation information...

          // create email history search link, if email is available
          $("#modColumnAdjustmentsRes > div > div.col-xs-8 > div > table > tbody > tr:nth-child(4)").attr("id", "modEmailLink");
          if ($("#modEmailLink > td:nth-child(2)").text().length !== 0) {
            $("#modEmailLink").attr("class", "li-dropdown").attr("title", "Search Email History");
            $("#modEmailLink > td:nth-child(2)").append(` <span class="glyphicon glyphicon-new-window"></span>`);
            $(document).on("click", "#modEmailLink", function (e) {
              window.open("/admin/tools/inbox/search?search=" + $("#modEmailLink > td:nth-child(2)").text(), "_blank");
            });
          }

          // create unit listing link
          $("#modColumnAdjustmentsRes > div > div.col-xs-8 > div > table > tbody > tr:nth-child(9)").attr("id", "modunit.codeLink");
          $("#modunit.codeLink").attr("class", "li-dropdown").attr("title", "View Public Listing");
          $("#modunit.codeLink > td:nth-child(2)").append(` <span class="glyphicon glyphicon-new-window"></span>`);
          $(document).on("click", "#modunit.codeLink", function (e) {
            window.open(unitLink, "_blank");
          });
        }

      },

      // EDIT RESERVATION: CREDIT TRANSFER
      // /admin/dashboard/reservation/finance/beginAdjustment ... adjustmentType=creditTransfer

      credit_transfer: function () {

        // SETTING: MAX TRANSFER BUTTON

        if (settings.MAX_TRANSFER === true) {
          let maxAmount = "",
            maxButton = "";

          // figure out the max funds available
          maxAmount = $("#transferAmount").attr("max");

          // create our button
          maxButton = `<SPAN class="input-group-btn"><DIV id="modMaxButton" class="btn btn-default">Max</DIV></SPAN>`;
          $("#transferAmount").after(maxButton);

          // do a thing when the new button is clicked
          $(document).on("click", "#modMaxButton", function (e) {
            $("#transferAmount").val(maxAmount);
          });
        }

      },

      // EDIT RESERVATION: CANCEL RESERVATION
      // /admin/dashboard/reservation/finance/beginAdjustment ... adjustmentType=cancelReservation

      cancel_res: function () {

        // CREATE HASHTAG DROPDOWN APPENDAGES

        let dropdownHtml = "",
          dropGuestHtml = "",
          dropOwnerHtml = "",
          dropVacasaHtml = "",
          hashAlertHtml = "";

        dropGuestHtml =
          `<option value="#CCdecline #Terms">Card Decline (Guest Disagreed to Payment Terms)</option>
          <option value="#CCdecline #Unresponsive">Card Decline (Guest Unresponsive)</option>
          <option value="#DateChange">Dates Have Changed</option>
          <option value="#ExC">Extenuating Circumstance</option>
          <option value="#HouseRules">House Rules</option>
          <option value="#ISF">Insufficient Funds</option>
          <option value="#Error">Made in Error</option>
          <option value="#NaturalDisaster">Natural Disaster</option>
          <option value="#TripChange">No Longer Need Accomodation</option>
          <option value="#RebookDirect">Rebooked Directly</option>
          <option value="#GracePeriod">Within Grace Period</option>
          <option value="#Other">Other</option>`;

        dropOwnerHtml =
          `<option value="#FM">Forced Move (Cancel & Refund)</option>
          <option value="#FM #Save">Forced Move (Moved to New Unit)</option>
          <option value="">Owner Cancellation</option>`;

        dropVacasaHtml =
          `<option value="#NaturalDisaster">Natural Disaster</option>
          <option value="#OOO">Unit Out of Order</option>
          <option value="#UnusedFMHold">Forced Move (Release Unused Hold)</option>`;

        dropdownHtml =
          `<div class="form-group">
            <label for="RES-CANCEL-requested">Requested By</label>
            <select id="RES-CANCEL-requested" class="form-control">
              <option value="#GuestCXLD">Guest</option>
              <option value="#OwnerCXLD">Owner</option>
              <option value="#VacasaCXLD">Vacasa</option>
            </select>
          </div>
          <div class="form-group">
            <label for="RES-CANCEL-reason">Reason</label>
            <select id="RES-CANCEL-reason" class="form-control">
              ${dropGuestHtml}
            </select>
          </div>`;

        hashAlertHtml =
          `<div class="col-sm-12 col-md-4 col-lg-4">
            <div class="alert alert-warning">
              <p>For tracking purposes, it is important that cancellation requests/reasons be chosen that most accurately fit the situation.</p>
              <div id="RES-CANCEL-current-tags">
                <h4>Current Tags:</h4>
                <span></span>
              </div>
            </div>
          </div>`;

        $("#adjustmentForm > div.panel.panel-default > div > div > label").text("Cancellation Details");

        $("#adjustmentForm > div.panel.panel-default > div > div > textarea[name='reason']").attr("placeholder", "Enter cancellation details");

        $("#adjustmentForm > div.panel.panel-default > div > div").wrapInner(`<div class="form-group"></div>`).prepend(dropdownHtml).after(hashAlertHtml);

        $(document).on("change", "#RES-CANCEL-requested", function (e) {
          switch ($(this).val()) {
            case "#GuestCXLD":
              $("#RES-CANCEL-reason").html(dropGuestHtml);
              break;
            case "#OwnerCXLD":
              $("#RES-CANCEL-reason").html(dropOwnerHtml);
              break;
            case "#VacasaCXLD":
              $("#RES-CANCEL-reason").html(dropVacasaHtml);
              break;
            default:
              break;
          }
        });

        $(document).on("change", "#RES-CANCEL-requested, #RES-CANCEL-reason", function (e) {
          $("#RES-CANCEL-current-tags > span").html(`<pre>${$("#RES-CANCEL-requested").val()} ${$("#RES-CANCEL-reason").val()}</pre>`);
        });

        $(document).ready(function (e) {
          $("#RES-CANCEL-current-tags > span").html(`<pre>${$("#RES-CANCEL-requested").val()} ${$("#RES-CANCEL-reason").val()}</pre>`);
        });

        $(document).on("click", "#rfo-adj-preview", function (e) {

          $("#adjustmentForm > div > div > div > div > textarea[name='reason']").val($("#adjustmentForm > div > div > div > div > textarea[name='reason']").val() + "\n\n" + $("#RES-CANCEL-requested").val() + " " + $("#RES-CANCEL-reason").val());

          $("#adjustmentForm").submit();

          return false;

        });

      },

      // NEW MAINTENANCE TICKET
      // /admin/dashboard/tickets/editMaintenance

      new_ticket: function () {

        // PARSE INCOMING PARAMETERS

        // load and populate our settings configuration
        RES.settings.init();

        let urlParameters = {};

        let param = {
          desc: "",
          details: ""
        }

        urlParameters = new URLSearchParams(window.location.search);

        param.desc = urlParameters.get("desc");
        param.details = urlParameters.get("details");

        if (param.desc) {
          $("#Title").val(param.desc);
        }
        if (param.details) {
          $("#Text").val(param.details);
        }
        if (settings.TICKET_TEMPLATE === true) {
          if (!param.desc && !param.details) {
            $("#Text").val("Guest Name: \nGuest Phone: \nDescription of Issue: \nTroubleshooting steps already taken: \nOkay to enter property: \nExpected timeline for resolution: ");
          }
        }
      }
    },


    // GLOBAL-ISH FUNCTIONS ///////////////////////////////////////////////////

    formatDate: function (date) {
      let dateFormatted = "";

      dateFormatted = date.substring(date.indexOf("-") + 1, date.lastIndexOf("-")) + "/" + date.substring(date.lastIndexOf("-") + 1, date.length) + "/" + date.substring(0, date.indexOf("-"));

      return dateFormatted;
    },

    indicateLoading: function (id, status, icon, newIcon, pulsate) {
      if (status === true) {

        if (pulsate === true) {
          $(`${id}`).addClass("pulsate");
        }

        $(`${id} > span`).addClass("fa-spinner fa-spin");
        $(`${id} > span`).removeClass(icon);

      } else {

        if (pulsate === true) {
          $(`${id}`).removeClass("pulsate");
        }

        $(`${id} > span`).removeClass("fa-spinner fa-spin");
        $(`${id} > span`).addClass(newIcon);

      }
    },

  };


  // MAIN /////////////////////////////////////////////////////////////////////

  // initialize
  RES.init();

  // load the correct module for our URL
  if (docUrl.indexOf("/admin/resedit.php") > -1) {
      RES.modules.resedit();
  } else if (docUrl.indexOf("/admin/dashboard/reservation/finance/edit?") > -1) {
    RES.modules.edit_finances();
  } else if (docUrl.indexOf("/admin/dashboard/reservation/finance/beginAdjustment?reservationId=") > -1 && docUrl.indexOf("&adjustmentType=creditTransfer") > -1) {
    RES.modules.credit_transfer();
  } else if (docUrl.indexOf("/admin/dashboard/reservation/finance/beginAdjustment?reservationId=") > -1 && docUrl.indexOf("&adjustmentType=cancelReservation") > -1) {
    RES.modules.cancel_res();
  } else if (docUrl.indexOf("/admin/dashboard/tickets/editMaintenance?") > -1) {
    RES.modules.new_ticket();
  }

})();
